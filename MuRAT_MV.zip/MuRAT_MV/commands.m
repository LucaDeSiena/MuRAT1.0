%COMMANDS for MuRAT

% Choose between P- (2) and S-direct (3) waves
PorS = 3;

% Work with 1 vertical (1) or 2 horizontal (2) registrations, or with the
% three components(3)
compon = 3;

% Step of the inversion required - set to 2 in case of double inversion
nstep= 1;

% Name of the file containing the 1st velocity model - according to PorS
modv = load('modv.txt','%f');
v0= mean(modv(:,4));
resol2 = abs(modv(2,3)-modv(1,3))/2;

% Name of the file containing the picking of origin time, P, and S waves
tempi = load('tempi.txt','%f');

% Length of the window used to measure P- or S- waves energy in
% seconds
fin = 1;

% Central frequency
cf = 18;

% Lapse time (from the origin time of the event) must be >> 2*tS
tC = 15;

% Total coda window length
tW = 10;

%UTM coordinates of the origin of the velocity model
originWE=447264;
originSN=4514889;
originz=900; %topography

%Rays are measured in meters. If the ray length is already in km set um =1;
um = 1000;

%In order to check the images, change the smoothing parameter (set=1)
smoot=0;

%The minimum coda-to-noise energy ratio
soilnoise = 1;

%Parameters for the second model
if nstep == 2
    modv2 = load('modv2.txt','%f');
    resol22 = abs(modv2(2,3)-modv2(1,3))/2;
    %You can choose to check the second images by changing the second
    %smoothing parameter (smoot2==1);
    smoot2 =0;
end
    
